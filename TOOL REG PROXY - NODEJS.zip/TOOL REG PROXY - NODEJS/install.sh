#!/bin/bash
npm install dotenv
chmod +x start.sh
chmod +x install.sh
echo "✅ Cài đặt hoàn tất."